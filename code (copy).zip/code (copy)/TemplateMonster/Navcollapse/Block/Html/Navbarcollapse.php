<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace TemplateMonster\Navcollapse\Block\Html;

/**
 * Html page header block
 */
class Navbarcollapse extends \Magento\Framework\View\Element\Template
{

}
