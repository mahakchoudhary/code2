var config = {

    paths: {
        sliderInit: 'TemplateMonster_FilmSlider/js/jquery.sliderPro',
        FilmSlider: 'TemplateMonster_FilmSlider/js/film-slider',
    },
    shim: {
    	"sliderInit": ["jquery"],
    }
};