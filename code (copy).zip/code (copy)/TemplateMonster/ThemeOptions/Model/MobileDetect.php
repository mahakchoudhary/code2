<?php

namespace TemplateMonster\ThemeOptions\Model;

require __DIR__ . '/../lib/mobiledetect/Mobile_Detect.php';

/**
 * MobileDetect library alias.
 *
 * @package TemplateMonster\ThemeOptions\Model
 */
class MobileDetect extends \Mobile_Detect
{

}