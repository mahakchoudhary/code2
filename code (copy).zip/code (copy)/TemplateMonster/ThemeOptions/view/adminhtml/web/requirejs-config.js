var config = {
    map: {
        '*': {
            'importButton': 'TemplateMonster_ThemeOptions/js/import-button'
        }
    }
};