<?php
namespace TemplateMonster\Blog\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const CONFIG_PATH_ACTIVE = 'tm_blog/general/active';
    const CONFIG_PATH_TITLE = 'tm_blog/general/title';
    const CONFIG_PATH_TOPLINK = 'tm_blog/general/toplink_active';
    const CONFIG_PATH_TOPLINK_LABEL = 'tm_blog/general/toplink_label';
    const CONFIG_PATH_ROUTE = 'tm_blog/general/route';
    const CONFIG_PATH_LIMITS = 'tm_blog/general/limits';
    const CONFIG_PATH_POST_LAYOUT = 'tm_blog/general/post_layout';
    const CONFIG_PATH_POST_LIST_LAYOUT = 'tm_blog/general/list_layout';
    const CONFIG_PATH_META_KEYWORDS = 'tm_blog/general/meta_keywords';
    const CONFIG_PATH_META_DESCRIPTION = 'tm_blog/general/meta_description';
    const CONFIG_PATH_RELATED_POSTS_ENABLE = 'tm_blog/post_view/related_posts/enabled';
    const CONFIG_PATH_RELATED_POSTS_NUMBER = 'tm_blog/post_view/related_posts/posts_number';
    const CONFIG_PATH_RELATED_PRODUCTS_ENABLE = 'tm_blog/post_view/related_products/enabled';
    const CONFIG_PATH_RELATED_PRODUCTS_NUMBER = 'tm_blog/post_view/related_products/products_number';

    protected $_scopeConfig;

    public function __construct(ScopeConfigInterface $scopeConfig)
    {
        $this->_scopeConfig = $scopeConfig;
    }

    protected function getConfigValue($path, $scope)
    {
        return $this->_scopeConfig->getValue($path, $scope);
    }

    public function isModuleActive()
    {
        return $this->getConfigValue(self::CONFIG_PATH_ACTIVE, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function isAllowTopLink()
    {
        return $this->getConfigValue(self::CONFIG_PATH_TOPLINK, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getLinkLabel()
    {
        return $this->getConfigValue(self::CONFIG_PATH_TOPLINK_LABEL, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getTitle()
    {
        return $this->getConfigValue(self::CONFIG_PATH_TITLE, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getRoute()
    {
        return $this->getConfigValue(self::CONFIG_PATH_ROUTE, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getLimits()
    {
        return $this->getConfigValue(self::CONFIG_PATH_LIMITS, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getPostLayout()
    {
        return $this->getConfigValue(self::CONFIG_PATH_POST_LAYOUT, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getPostListLayout()
    {
        return $this->getConfigValue(
            self::CONFIG_PATH_POST_LIST_LAYOUT,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getMetaKeywords()
    {
        return $this->getConfigValue(self::CONFIG_PATH_META_KEYWORDS, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getMetaDescription()
    {
        return $this->getConfigValue(
            self::CONFIG_PATH_META_DESCRIPTION,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function isRelatedPostsEnabled()
    {
        return $this->getConfigValue(
            self::CONFIG_PATH_RELATED_POSTS_ENABLE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getRelatedPostsNumber()
    {
        return $this->getConfigValue(
            self::CONFIG_PATH_RELATED_POSTS_NUMBER,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function isRelatedProductsEnabled()
    {
        return $this->getConfigValue(
            self::CONFIG_PATH_RELATED_PRODUCTS_ENABLE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getRelatedProductsNumber()
    {
        return $this->getConfigValue(
            self::CONFIG_PATH_RELATED_PRODUCTS_NUMBER,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

}