<?php
namespace TemplateMonster\Blog\Block\Post;

use \Magento\Framework\View\Element\Template;
use \Magento\Framework\DataObject;
use \TemplateMonster\Blog\Model\ResourceModel\Post\Collection;
use \TemplateMonster\Blog\Block\Post\PostList\Toolbar;
use \TemplateMonster\Blog\Model\Url;
use \Magento\Cms\Model\Template\FilterProvider;

class PostList extends Template
{
    const DEFAULT_SORT_DIRECTION = 'asc';

    protected $_postCollection;

    protected $_urlModel;

    /**
     * @param Template\Context $context
     * @param Collection $postCollection
     * @param FilterProvider $filterProvider
     * @param Toolbar $toolbar
     * @param Url $url
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        Collection $postCollection,
        FilterProvider $filterProvider,
        Toolbar $toolbar,
        Url $url,
        array $data = []
    ) {
        $this->_urlModel = $url;
        $this->_postCollection = $postCollection;
        $this->_toolbar = $toolbar;
        $this->_filterProvider = $filterProvider;
        parent::__construct($context, $data);
    }

    /**
     * Get modified collection object with set order
     *
     * @return Collection
     */
    public function getCollection()
    {
        return $this->_getPostCollection();
    }

    protected function _getPostCollection()
    {
        return $this->_postCollection;
    }

    protected function _prepareData()
    {
        $this->_postCollection
            ->addFieldToFilter('is_visible', true)
            ->addStoreFilter($this->_storeManager->getStore()->getId());
    }

    protected function _beforeToHtml()
    {
        $this->_prepareData();
        $this->_toolbar->setCollection($this->_getPostCollection());
        $this->_getPostCollection()->load();

        return parent::_beforeToHtml();
    }

    /**Filter content to display cms data
     * @param $data
     * @return mixed
     */
    public function filterContent($data)
    {
        return $this->_filterProvider->getBlockFilter()->filter($data);
    }

    public function getPostUrl($post)
    {
        return $this->getUrl($this->_urlModel->getPostRoute($post));
    }
}
