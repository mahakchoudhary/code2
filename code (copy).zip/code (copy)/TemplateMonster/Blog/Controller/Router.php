<?php
namespace TemplateMonster\Blog\Controller;

use Magento\Framework\App\ActionFactory;
use Magento\Framework\App\RequestInterface;
use TemplateMonster\Blog\Helper\Data;
use TemplateMonster\Blog\Model\Url;

class Router implements \Magento\Framework\App\RouterInterface
{
    const MODULE_PATH = 'tm_blog';

    protected $_actionFactory;

    protected $_helper;

    protected $_urlModel;

    public function __construct(
        ActionFactory $actionFactory,
        Data $helper,
        Url $url
    ) {
        $this->_actionFactory = $actionFactory;
        $this->_helper = $helper;
    }

    /**
     * Allows to use dynamic routing
     *
     * @param \Magento\Framework\App\RequestInterface $request
     * @return \Magento\Framework\App\ActionInterface|null
     */
    public function match(
        RequestInterface $request
    ) {
        $info = trim($request->getPathInfo(), '/');
        $pathInfo = explode('/', $info);
        $route = $this->_helper->getRoute();

        if (!$this->_helper->isModuleActive()) {
            return null;
        }

        if ($pathInfo[0] == $route) {
            $modulePath = self::MODULE_PATH;
            if (isset($pathInfo[1])) {
                if ($pathInfo[1] == 'saveComment') {
                    $modulePath .= '/post/saveComment';
                } elseif ($pathInfo[1]) {
                    $modulePath .= '/post/view';
                    $request->setParam('post_identifier', $pathInfo[1]);
                }
            }
            $request->setPathInfo($modulePath);
            return $this->_actionFactory->create('Magento\Framework\App\Action\Forward');
        }
        return null;
    }
}
