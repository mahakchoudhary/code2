<?php
namespace TemplateMonster\Blog\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use TemplateMonster\Blog\Helper\Data as HelperData;

class Index extends \Magento\Framework\App\Action\Action
{
    protected $resultPageFactory;
    protected $_helper;

    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        HelperData $helper
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_helper = $helper;

        parent::__construct($context);
    }

    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->getConfig()->setPageLayout($this->_helper->getPostListLayout());

        //Set Page title
        $pageTitle = $this->_helper->getTitle();
        $resultPage->getConfig()->getTitle()->set(__($pageTitle));

        return $resultPage;
    }
}
