var config = {
    map: {
        '*': {
            'ajaxWishlist': 'TemplateMonster_AjaxWishlist/js/ajaxwishlist',
            'wishlist': 'TemplateMonster_AjaxWishlist/js/wishlist'
        }
    }
};