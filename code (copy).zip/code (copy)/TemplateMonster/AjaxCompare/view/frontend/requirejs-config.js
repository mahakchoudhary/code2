var config = {
    map: {
        '*': {
             "compareItems" : "TemplateMonster_AjaxCompare/js/tm-compare-ajax",
             "showCompareProduct" : "TemplateMonster_AjaxCompare/js/compare-products-top-link",
        }
    }
};
