<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mobilyte\CustomContact\Controller\Index;


use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\ObjectManager;

class Post extends \Magento\Contact\Controller\Index
{
    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;


    /**
     * Post user question
     *
     * @return void
     * @throws \Exception
     */
    public function execute()
    {




$model = $this->_objectManager->get('Magento\Variable\Model\Variable')->loadByCode('invoice_prefix');
$plain_value = $model->getPlainValue();
$html_value = $model->getHtmlValue();
$name = $model->getName();




// print_r($_REQUEST);
// echo "AAAABBCC";        
// print_r("aaaaaaaaaaaaaaaaaaaaaaaaaa")        ;
        $post = $this->getRequest()->getPostValue();
// echo "<pre>";
// print_r($post);
// echo "</pre>";
// die("aaaaaaa");

        if (!$post) {
            $this->_redirect('*/*/');
            return;
        }

        $this->inlineTranslation->suspend();



        try
        {
            $postObject = new \Magento\Framework\DataObject();
            $postObject->setData($post);

            $error = false;

            if (!\Zend_Validate::is(trim($post['name']), 'NotEmpty')) {
                $error = true;
            }
            if (!\Zend_Validate::is(trim($post['comment']), 'NotEmpty')) {
                $error = true;
            }
            if (!\Zend_Validate::is(trim($post['email']), 'EmailAddress')) {
                $error = true;
            }
            if (\Zend_Validate::is(trim($post['hideit']), 'NotEmpty')) {
                $error = true;
            }
            if ($error) {
                throw new \Exception();
            }


// $_objectManager = \Magento\Framework\App\ObjectManager::getInstance();
// $storeManager = $_objectManager->get('Magento\Store\Model\StoreManagerInterface'); 
// $currentStore = $storeManager->getStore();
// echo $baseUrl = $currentStore->getBaseUrl();
// echo $path = $currentStore->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
// echo "<br>";
// echo $path = '/var/www/html/retrofit/trunk/pub/media/contacts/abc.jpg';
// echo "<br>";

// echo "<pre>";
// print_r($post);
// echo "</pre>";




$getFileName = '';            
if( $post['custom'] == 2)
{

// die("in the file upload..");
   $fp = fopen("/var/www/html/retrofit/trunk/var/atestlog.txt", "a");
   // fwrite($fp, '\n \t test log \n' . $this->scopeConfig->getValue(self::XML_PATH_EMAIL_RECIPIENT, $storeScope));

            $getFileName = '';
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultRedirectFactory->create();

            // try{
                $target = $this->_mediaDirectory->getAbsolutePath('contacts/');
                /** @var $uploader \Magento\MediaStorage\Model\File\Uploader */
                $uploader = $this->_fileUploaderFactory->create(['fileId' => 'attachment']);
                $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png', 'zip', 'doc']);
                $uploader->setAllowRenameFiles(true);                                                   
                $result = $uploader->save($target);
                // if ($result['file']) {
                //     $this->messageManager->addSuccess(__('File has been successfully uploaded')); 
                // }
            // } catch (\Exception $e) {
            //     $this->messageManager->addError($e->getMessage());
            // }

            $getFileName = $this->resultRedirectFactory->create()->setPath(
                '*/*/upload', ['_secure'=>$this->getRequest()->isSecure()]
            );


            if ($result['file']) {
            $urlInterface = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\UrlInterface');
            $attachmentFileName = $urlInterface->getUrl('pub/media/contacts/', ['_secure' => $this->getRequest()->isSecure()]);

            $attachmentFileNameAbsolutePath = $target . $result['file'];

            $post['attachment'] = ($result['file']) ? $attachmentFileName . $result['file'] : 'NA';
            $postObject->setData($post);

           fwrite($fp, '\n \t upload log 1 start');
           fwrite($fp, '\n \t CCCCCCCCCCCCCC');
           fwrite($fp, '\n \t ' . $attachmentFileName);
           fwrite($fp, '\n \t DDDDDDDDDDDDDDDDD');
            }

   // fwrite($fp, '\n \t test log \n' . print_r($postObject, true));
   // // fwrite($fp, '\n \t test log \n' . $this->scopeConfig->getValue(self::XML_PATH_EMAIL_SENDER, $storeScope));
   fwrite($fp, '\n \t upload log 1 end');
   // // fwrite($fp, '\n \t test log  \n');
   // // fwrite($fp, '\n \t test log  \n' . $post['email'] . 'filename : ' . $getFileName);
   // fclose($fp);
}





            if( $post['custom'] == 1 || $post['custom'] == 2)
            {



            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            $transport = $this->_transportBuilder
                ->setTemplateIdentifier( $post['email_template_id'])
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Backend\App\Area\FrontNameResolver::AREA_CODE,
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )
                ->setTemplateVars(['data' => $postObject])
                ->setFrom($this->scopeConfig->getValue(self::XML_PATH_EMAIL_SENDER, $storeScope))
                ->addTo($this->scopeConfig->getValue(self::XML_PATH_EMAIL_RECIPIENT, $storeScope))
                ->setReplyTo($post['email'])
                ->addAttachment( $attachmentFileNameAbsolutePath, basename($attachmentFileNameAbsolutePath), 'jpg' )
                ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();

// // fwrite($fp, '\n \t test log  \n' . $post['email'] . 'filename : ' . $getFileName);



                $this->messageManager->addSuccess(
                    __('Thanks for sending query. We\'ll respond to you very soon.')
                ); 
            $this->getDataPersistor()->clear('contact_us');
            $this->_redirect( $post['return_url']);
            // if($post['custom'] == 1)
            // $this->_redirect('upload-product-1');
            // else if($post['custom'] == 2)
            // $this->_redirect('upload-product-2');
            return;
            }
            else
            {
$fp = fopen("/var/www/html/retrofit/trunk/var/atestlog.txt", "a");
fwrite($fp, '\n \t bbb \n');

            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            $transport = $this->_transportBuilder
                ->setTemplateIdentifier($this->scopeConfig->getValue(self::XML_PATH_EMAIL_TEMPLATE, $storeScope))
                ->setTemplateOptions(
                    [
                        'area' => \Magento\Backend\App\Area\FrontNameResolver::AREA_CODE,
                        'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                    ]
                )
                ->setTemplateVars(['data' => $postObject])
                ->setFrom($this->scopeConfig->getValue(self::XML_PATH_EMAIL_SENDER, $storeScope))
                ->addTo($this->scopeConfig->getValue(self::XML_PATH_EMAIL_RECIPIENT, $storeScope))
                ->setReplyTo($post['email'])
                ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();

// die("aaaaaaaaaaa");
fwrite($fp, '\n \t aaaaaaaaaaa \n');
fclose($fp);




                $this->messageManager->addSuccess(
                    __('Thanks for contacting us with your comments and questions. We\'ll respond to you very soon.')
                );
            $this->getDataPersistor()->clear('contact_us');
            $this->_redirect('thankyou');
            return;                
            }

        }
         catch (\Exception $e) {
            $this->inlineTranslation->resume();
            $this->messageManager->addError(
                __('We can\'t process your request right now. Sorry, that\'s all we know.')
            );
            if( $post['custom'] == 1 || $post['custom'] == 2)
            {
                // die('ifffff exception..');
                $this->getDataPersistor()->set('contact_us', $post);
                $this->_redirect( $post['return_url']);
                // if($post['custom'] == 1)
                // $this->_redirect('upload-product-1');
                // else if($post['custom'] == 2)
                // $this->_redirect('upload-product-2');
                return;
            }
            else
            {
                // die('elseeee exception..');
                $this->getDataPersistor()->set('contact_us', $post);
                $this->_redirect('contact/index');
                return;
            }

        }
    }

    /**
     * Get Data Persistor
     *
     * @return DataPersistorInterface
     */
    private function getDataPersistor()
    {
        if ($this->dataPersistor === null) {
            $this->dataPersistor = ObjectManager::getInstance()
                ->get(DataPersistorInterface::class);
        }

        return $this->dataPersistor;
    }
}
