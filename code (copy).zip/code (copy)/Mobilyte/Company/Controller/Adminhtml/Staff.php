<?php

namespace Mobilyte\Company\Controller\Adminhtml;

abstract class Staff extends \Mobilyte\Company\Controller\Adminhtml\AbstractAction
{
    const PARAM_CRUD_ID = 'staff_id';

    
    protected function _isAllowed()
    {
    	// die('aaaaaaaaaaaaaaaa');
        return $this->_authorization->isAllowed('Mobilyte_Company::company_staff');
    }
}