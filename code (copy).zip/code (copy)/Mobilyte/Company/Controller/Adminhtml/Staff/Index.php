<?php

namespace Mobilyte\Company\Controller\Adminhtml\Staff;


class Index extends \Mobilyte\Company\Controller\Adminhtml\Staff
{
    
    public function execute()
    {
    	// die('bbbbbbbbbb');

        $resultPage = $this->_resultPageFactory->create();

        return $resultPage;
    }
}
