<?php
/**
 * @copyright   Copyright (c) http://www.manadev.com
 * @license     http://www.manadev.com/license  Proprietary License
 */

namespace Manadev\LayeredNavigation\Registries\FilterIndexers;

class PrimaryFilterIndexers extends BaseFilterIndexers
{

}